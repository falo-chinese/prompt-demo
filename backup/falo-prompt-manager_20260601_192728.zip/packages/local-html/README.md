# Local HTML MVP

這是 FALO Prompt Manager 的本地版 MVP。

## 目標

- 單頁 HTML / PWA，可用瀏覽器開啟，也可透過 localhost 安裝
- 不依賴外部 CDN
- 內建範例 Prompt Card
- 可匯入 JSON prompt database
- 支援變數即時代入
- 一鍵複製完整 Prompt
- 匯出與一鍵備份 JSON
- Light / Dark / Teaching 皮膚
- Web Speech API 輕量語音輸入，輸出到 `[Voice_Text]`
- OCR / Gemini Cloud API 預留欄位，主線仍是外部工具輸出 JSON 再匯入
- OCR 影像策略參考 WebP 768、PNG standard、不放大小圖；匯出只保留 metadata，不保存圖片 bytes

## 開啟方式

直接開啟：

`index.html`

或用本地靜態伺服器預覽：

```bash
python3 -m http.server 4173
```

再開啟：

`http://localhost:4173/packages/local-html/index.html`

## 匯入資料

可以匯入：

`../../examples/prompt_database_template.json`

目前支援兩種資料格式：

1. 新版 schema：category array
2. 舊版原型：object key 作為 category title
3. v0.3 匯出格式：`promptCategories` + `prompts`
4. Input Material JSON：`type: "inputMaterial"`

Excel 匯入與 GAS 同步會在後續版本補上；本版先穩定最小本地 JSON / PWA / Voice 流程。

## PWA 測試

PWA 安裝與 service worker 需要 `localhost` 或 HTTPS。

```bash
python3 -m http.server 4173
```

再開啟：

`http://localhost:4173/packages/local-html/index.html`
